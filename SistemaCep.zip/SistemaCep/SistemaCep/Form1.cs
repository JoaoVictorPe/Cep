namespace SistemaCep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtCep.Text.Equals(""))
                {
                    Endere�o endere�o = buscarcep.BuscarCEP(txtCep.Text);
                    lblLogResultado.Text = endere�o.Logradouro;
                    lblLocRe.Text = endere�o.Localidade;
                    lblBairroRe.Text = endere�o.Bairro;
                    lblUFRe.Text = endere�o.UF;
                }
                else
                {
                    MessageBox.Show("Favor preencher campo cep para realizar a busca.", "Erro - campo em branco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtCep.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar cep" + ex.Message);
            }
        }
    }
}
