﻿namespace SistemaCep
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel2 = new Panel();
            lblUFRe = new Label();
            lblLocRe = new Label();
            lblBairroRe = new Label();
            lblLogResultado = new Label();
            lblUF = new Label();
            lblLocalidade = new Label();
            lblBairro = new Label();
            lblLogradouro = new Label();
            btnBuscar = new Button();
            txtCep = new TextBox();
            lblInfocep = new Label();
            txtBucarCep = new Label();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.MenuHighlight;
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(492, 26);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(423, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(28, 50);
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(457, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 50);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(12, 3);
            label1.Name = "label1";
            label1.Size = new Size(115, 20);
            label1.TabIndex = 0;
            label1.Text = "Buscador de Cep";
            // 
            // panel2
            // 
            panel2.Controls.Add(lblUFRe);
            panel2.Controls.Add(lblLocRe);
            panel2.Controls.Add(lblBairroRe);
            panel2.Controls.Add(lblLogResultado);
            panel2.Controls.Add(lblUF);
            panel2.Controls.Add(lblLocalidade);
            panel2.Controls.Add(lblBairro);
            panel2.Controls.Add(lblLogradouro);
            panel2.Controls.Add(btnBuscar);
            panel2.Controls.Add(txtCep);
            panel2.Controls.Add(lblInfocep);
            panel2.Controls.Add(txtBucarCep);
            panel2.Controls.Add(pictureBox2);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 26);
            panel2.Name = "panel2";
            panel2.Size = new Size(492, 577);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // lblUFRe
            // 
            lblUFRe.AutoSize = true;
            lblUFRe.Location = new Point(302, 425);
            lblUFRe.Name = "lblUFRe";
            lblUFRe.Size = new Size(0, 15);
            lblUFRe.TabIndex = 12;
            // 
            // lblLocRe
            // 
            lblLocRe.AutoSize = true;
            lblLocRe.Location = new Point(302, 395);
            lblLocRe.Name = "lblLocRe";
            lblLocRe.Size = new Size(0, 15);
            lblLocRe.TabIndex = 11;
            // 
            // lblBairroRe
            // 
            lblBairroRe.AutoSize = true;
            lblBairroRe.Location = new Point(302, 361);
            lblBairroRe.Name = "lblBairroRe";
            lblBairroRe.Size = new Size(0, 15);
            lblBairroRe.TabIndex = 10;
            // 
            // lblLogResultado
            // 
            lblLogResultado.AutoSize = true;
            lblLogResultado.Location = new Point(302, 331);
            lblLogResultado.Name = "lblLogResultado";
            lblLogResultado.Size = new Size(0, 15);
            lblLogResultado.TabIndex = 9;
            // 
            // lblUF
            // 
            lblUF.AutoSize = true;
            lblUF.Location = new Point(57, 425);
            lblUF.Name = "lblUF";
            lblUF.Size = new Size(24, 15);
            lblUF.TabIndex = 8;
            lblUF.Text = "UF:";
            // 
            // lblLocalidade
            // 
            lblLocalidade.AutoSize = true;
            lblLocalidade.Location = new Point(57, 395);
            lblLocalidade.Name = "lblLocalidade";
            lblLocalidade.Size = new Size(67, 15);
            lblLocalidade.TabIndex = 7;
            lblLocalidade.Text = "Localidade:";
            // 
            // lblBairro
            // 
            lblBairro.AutoSize = true;
            lblBairro.Location = new Point(57, 361);
            lblBairro.Name = "lblBairro";
            lblBairro.Size = new Size(41, 15);
            lblBairro.TabIndex = 6;
            lblBairro.Text = "Bairro:";
            lblBairro.Click += label5_Click;
            // 
            // lblLogradouro
            // 
            lblLogradouro.AutoSize = true;
            lblLogradouro.Location = new Point(57, 331);
            lblLogradouro.Name = "lblLogradouro";
            lblLogradouro.Size = new Size(72, 15);
            lblLogradouro.TabIndex = 5;
            lblLogradouro.Text = "Logradouro:";
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = SystemColors.Highlight;
            btnBuscar.ForeColor = SystemColors.ControlLightLight;
            btnBuscar.Location = new Point(302, 267);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(95, 24);
            btnBuscar.TabIndex = 2;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = false;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // txtCep
            // 
            txtCep.Location = new Point(37, 269);
            txtCep.Name = "txtCep";
            txtCep.Size = new Size(208, 23);
            txtCep.TabIndex = 1;
            // 
            // lblInfocep
            // 
            lblInfocep.AutoSize = true;
            lblInfocep.Location = new Point(37, 251);
            lblInfocep.Name = "lblInfocep";
            lblInfocep.Size = new Size(86, 15);
            lblInfocep.TabIndex = 2;
            lblInfocep.Text = "Informe o Cep:";
            // 
            // txtBucarCep
            // 
            txtBucarCep.AutoSize = true;
            txtBucarCep.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtBucarCep.ForeColor = SystemColors.Highlight;
            txtBucarCep.Location = new Point(203, 57);
            txtBucarCep.Name = "txtBucarCep";
            txtBucarCep.Size = new Size(194, 37);
            txtBucarCep.TabIndex = 1;
            txtBucarCep.Text = "Buscar Cep";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 17);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(157, 171);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(492, 603);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private Label label1;
        private Label txtBucarCep;
        private PictureBox pictureBox2;
        private Label lblUFRe;
        private Label lblLocRe;
        private Label lblBairroRe;
        private Label lblLogResultado;
        private Label lblUF;
        private Label lblLocalidade;
        private Label lblBairro;
        private Label lblLogradouro;
        private Button btnBuscar;
        private TextBox txtCep;
        private Label lblInfocep;
    }
}
