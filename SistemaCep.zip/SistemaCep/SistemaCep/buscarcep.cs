﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;

namespace SistemaCep
{
    class buscarcep
    {
        public static Endereço BuscarCEP(string cep)
        {
            try
            {
                string url = $"https://viacep.com.br/ws/{cep}/json/";
                using (WebClient client = new WebClient())
                {
                    string json = client.DownloadString(url);
                    Endereço endereço = JsonConvert.DeserializeObject<Endereço>(json);
                    return endereço;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível retornar as informações do cep: " + ex.Message, "Erro - busca cep", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

    }
}
